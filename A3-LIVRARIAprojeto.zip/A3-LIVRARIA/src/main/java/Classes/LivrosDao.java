package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LivrosDao {

    ArrayList<Livro> lista = new ArrayList<>();

    Connection cn;

    public LivrosDao() {
       this.cn = FabricaConexao.getConnection();
    }

    public String Cadastrar(Livro l) {
        String ret = "OK";
        String sql = "INSERT INTO livros (titulo, autor, genero, editora, isbn, serie, bimestre)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement st = cn.prepareStatement(sql);

            st.setString(1, l.getTitulo());
            st.setString(2, l.getAutor());
            st.setString(3, l.getGenero());
            st.setString(4, l.getEditora());
            st.setString(5, l.getIsbn());
            st.setString(6, l.getSerie());
            st.setString(7, l.getBimestre());

            st.execute();

        } catch (SQLException e) {
            ret = "ERRO" + e.getMessage();
        }

        return ret;
    }

    public String Atualizar(Livro l) {
        String ret = "OK";
        String sql = "UPDATE livros SET titulo=?, genero=?, editora=?, isbn=?, serie=?, bimestre=? ";

        try {
            PreparedStatement st = cn.prepareStatement(sql);

            st.setString(1, l.getTitulo());
            st.setString(2, l.getGenero());
            st.setString(3, l.getEditora());
            st.setString(4, l.getIsbn());
            st.setString(5, l.getSerie());
            st.setString(6, l.getBimestre());

            st.execute();

        } catch (SQLException e) {
            ret = "ERRO" + e.getMessage();
        }

        return ret;
    }

    public String Excluir(String titulo) {
    String ret = "OK";
    String sql = "DELETE FROM livros WHERE titulo = ?";
    try {
        PreparedStatement st = cn.prepareStatement(sql);
        st.setString(1, titulo);
        int rowsAffected = st.executeUpdate();

        if (rowsAffected == 0) {
            ret = "ERRO: Nenhum registro encontrado com o título informado.";
        }
    } catch (SQLException e) {
        ret = "ERRO: " + e.getMessage();
    }
    return ret;
}


    public ArrayList<Livro> getAll() {
        ArrayList<Livro> lista = new ArrayList<>();

        ResultSet rs;
        String sql = "SELECT * FROM livros";

        try (PreparedStatement st = cn.prepareStatement(sql)) {
            rs = st.executeQuery();

            while (rs.next()) {
                Livro l = new Livro();

                l.setTitulo(rs.getString("titulo"));
                l.setAutor(rs.getString("autor"));
                l.setGenero(rs.getString("genero"));
                l.setEditora(rs.getString("editora"));
                l.setIsbn(rs.getString("isbn"));
                l.setSerie(rs.getString("serie"));
                l.setBimestre(rs.getString("bimestre"));

                lista.add(l);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return lista;
    }

}
